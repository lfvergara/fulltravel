<?php

include_once SETSAIL_TWITTER_SHORTCODES_PATH . '/twitter-list/functions.php';
include_once SETSAIL_TWITTER_SHORTCODES_PATH . '/twitter-list/twitter-list.php';