<?php

include_once SETSAIL_CORE_SHORTCODES_PATH . '/accordions/functions.php';
include_once SETSAIL_CORE_SHORTCODES_PATH . '/accordions/accordion.php';
include_once SETSAIL_CORE_SHORTCODES_PATH . '/accordions/accordion-tab.php';