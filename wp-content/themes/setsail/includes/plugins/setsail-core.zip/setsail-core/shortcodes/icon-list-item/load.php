<?php

include_once SETSAIL_CORE_SHORTCODES_PATH . '/icon-list-item/functions.php';
include_once SETSAIL_CORE_SHORTCODES_PATH . '/icon-list-item/icon-list-item.php';