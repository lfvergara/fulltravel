<?php

define('SETSAIL_TOURS_VERSION', '1.0.5');
define('SETSAIL_TOURS_ABS_PATH', dirname(__FILE__));
define('SETSAIL_TOURS_REL_PATH', dirname(plugin_basename(__FILE__)));
define('SETSAIL_TOURS_URL_PATH', plugin_dir_url( __FILE__ ));
define('SETSAIL_TOURS_CPT_PATH', SETSAIL_TOURS_ABS_PATH.'/post-types');
define('SETSAIL_TOURS_ASSETS_PATH', SETSAIL_TOURS_ABS_PATH.'/assets');
define('SETSAIL_TOURS_ASSETS_URL_PATH', SETSAIL_TOURS_URL_PATH.'assets');
define('SETSAIL_TOURS_PAYPAL_SENDBOX', false);
