<div class="qodef-tours-search-content">
	<div <?php setsail_tours_class_attribute($list_classes);?>>
		<div class="qodef-tours-row-inner-holder qodef-grid-normal-gutter">
			<?php echo setsail_tours_get_search_page_items_loop_html($tours_list); ?>
		</div>
	</div>
</div>