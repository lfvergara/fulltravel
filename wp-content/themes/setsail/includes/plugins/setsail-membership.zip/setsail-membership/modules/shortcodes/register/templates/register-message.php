<div class="qodef-register-notice">
	<h5 class="qodef-register-notice-title"><?php echo esc_html($message); ?></h5>
	<a href="#" class="qodef-login-action-btn" data-el="#qodef-login-content" data-title="<?php esc_attr_e('LOGIN', 'setsail-membership'); ?>"><?php esc_html_e('LOGIN', 'setsail-membership'); ?></a>
</div>